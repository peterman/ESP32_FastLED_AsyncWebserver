// Wi-Fi network to connect to (if not in AP mode)
char* ssid = "fastled";
char* password = "1234567890";

// Editor Access
const char* editor_username = "admin";
const char* editor_password = "admin";
